const config = {
    apiKey: "AIzaSyB7ORSBASdZUblaiJ1YdYn_QnfBLrXZE7o",
    authDomain: "note-2025d.firebaseapp.com",
    databaseURL: "https://note-2025d.firebaseio.com",
    projectId: "note-2025d",
    storageBucket: "note-2025d.appspot.com",
    messagingSenderId: "313984536951"
};
export default config;
const objectAssign = require('object-assign');

class Data {
    constructor() {
        this.data = {};
    }
    setData(key, data){
    	let obj = {};
    	obj[key] = data;
    	this.data = objectAssign(this.data, obj)
    }
    getData(key){
	    if (key) {
	    	return this.data[key]
	    } else {
	    	return this.data
	    }
    }
}

module.exports = new Data();